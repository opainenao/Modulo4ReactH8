import React, { useState } from 'react';
import Navbar from './Navbar';
import Home from './Home';
import Footer from './Footer';
import Login from './Login';

{/*const App = () => {
  return (
  <div>
  <Navbar />
  <Home />
  <RegisterPage />
  <Footer />
  </div>
  );
 */ };
  
  

function App() {
  const [isLoginVisible, setIsLoginVisible] = useState(false);

  return (
    <div className="d-flex flex-column justify-content-between min-vh-100">
      <Navbar
        isLoginVisible={isLoginVisible}
        onLoginClick={() => setIsLoginVisible(true)}
        onHomeClick={() => setIsLoginVisible(false)}
      />
      <div className="d-flex justify-content-center align-items-center flex-grow-1">
        {isLoginVisible ? <Login /> : <Home />}
      </div>
      {!isLoginVisible && <Footer />}
    </div>
  );
}

export default App;
