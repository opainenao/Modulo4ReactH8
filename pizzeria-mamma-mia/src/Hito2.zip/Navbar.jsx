import React from 'react';

const Navbar = ({ onLoginClick, onHomeClick, isLoginVisible }) => (
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
    <div className="container d-flex justify-content-between align-items-center">
      <a className="navbar-brand mx-auto" href="#">
        🍕 Pizzería Mamma Mia
      </a>
      {isLoginVisible ? (
        <button
          className="btn btn-light mx-1"
          onClick={onHomeClick}
        >
          Volver al Home
        </button>
      ) : (
        <button
          className="btn btn-warning mx-1"
          onClick={onLoginClick}
        >
          🔐 Login
        </button>
      )}
    </div>
  </nav>
);

export default Navbar;
