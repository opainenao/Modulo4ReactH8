export const formatPrecio = (price) => price.toLocaleString('es-CL', { style: 'currency', currency: 'CLP' });
