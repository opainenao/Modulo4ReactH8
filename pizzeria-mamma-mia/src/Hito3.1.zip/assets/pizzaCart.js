const pizzaCart = [
    {
      name: "Pizza Margherita",
      price: 8299,
      quantity: 2,
      image: "path/to/image.jpg"
    },
    {
      name: "Pizza Pepperoni",
      price: 9999,
      quantity: 1,
      image: "path/to/image.jpg"
    },
    // ... más pizzas
  ];
  
  export default pizzaCart;
  