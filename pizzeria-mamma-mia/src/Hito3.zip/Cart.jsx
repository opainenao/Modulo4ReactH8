import React from 'react';

const Cart = ({ cart, setCart }) => {
  // Función para aumentar la cantidad
  const handleIncrease = (index) => {
    const updatedCart = [...cart];
    updatedCart[index].quantity += 1;
    setCart(updatedCart);
  };

  // Función para disminuir la cantidad
  const handleDecrease = (index) => {
    const updatedCart = [...cart];
    if (updatedCart[index].quantity > 1) {
      updatedCart[index].quantity -= 1;
    }
    setCart(updatedCart);
  };

  // Calcula el total, asegurándose de que price sea un número
  const total = cart.reduce((sum, pizza) => {
    // Primero, aseguramos que pizza.price sea un número
    const price = 5000//Number(pizza.price);
    
    // Verificar si pizza.price es un número válido
    if (isNaN(price)) {
      console.error('Error: El precio no es un número válido:', pizza.price);
      return sum; // Si no es un número, no lo agregamos al total
    }

    // Sumar el precio de la pizza multiplicado por la cantidad
    return sum + (price * pizza.quantity);
  }, 0);

  console.log('Total calculado:', total); // Muestra el total calculado

  return (
    <div className="container mt-5">
      <h2>Carrito de Compras</h2>
      {cart.length === 0 ? (
        <p>No tienes productos en el carrito.</p>
      ) : (
        cart.map((pizza, index) => (
          <div key={index} className="d-flex justify-content-between align-items-center mb-3">
            <img src={pizza.img} alt={pizza.name} style={{ width: '50px' }} />
            <div>
              <h5>{pizza.name}</h5>
              <p>Precio: ${pizza.price}</p> {/* Aquí formateamos solo para mostrar */}
              <p>Cantidad: {pizza.quantity}</p>
            </div>
            <div>
              <button className="btn btn-outline-primary" onClick={() => handleIncrease(index)}>+</button>
              <button className="btn btn-outline-danger mx-2" onClick={() => handleDecrease(index)}>-</button>
            </div>
          </div>
        ))
      )}
      <h4>Total: ${total}</h4> {/* Formateamos el total con separadores de miles */}
      <button className="btn btn-success">Pagar</button>
    </div>
  );
};

export default Cart;
